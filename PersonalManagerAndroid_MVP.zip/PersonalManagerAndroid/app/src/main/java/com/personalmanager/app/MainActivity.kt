package com.personalmanager.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

private val Bg = Color(0xFF101010)
private val Panel = Color(0xFF1C1C1C)
private val Orange = Color(0xFFFF7A00)
private val Gold = Color(0xFFD6AD55)
private val Muted = Color(0xFFAAAAAA)
private const val PREFS = "personal_manager"
private const val TASKS = "tasks"

data class TaskItem(val id: Long, val title: String, val done: Boolean)

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { PersonalManagerApp(this) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("tasks", "یادآوری کارها", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

@Composable
fun PersonalManagerApp(context: Context) {
    var tab by remember { mutableStateOf(0) }
    var tasks by remember { mutableStateOf(loadTasks(context)) }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Orange, secondary = Gold, background = Bg, surface = Panel
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Orange) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Today, null) }, label = { Text("امروز") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Flag, null) }, label = { Text("اهداف") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.AutoAwesome, null) }, label = { Text("دستیار AI") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> TodayScreen(tasks, { tasks = it; saveTasks(context, it) }, Modifier.padding(padding))
                1 -> GoalsScreen(Modifier.padding(padding))
                else -> AssistantScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
        Text(title, color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun TodayScreen(tasks: List<TaskItem>, update: (List<TaskItem>) -> Unit, modifier: Modifier = Modifier) {
    var newTask by remember { mutableStateOf("") }
    val done = tasks.count { it.done }
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Header("مدیر شخصی من", "هر روز یک قدم نزدیک‌تر به هدف‌هات")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("برنامه امروز", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Text("${tasks.size} کار  •  $done انجام‌شده", color = Gold)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { if (tasks.isEmpty()) 0f else done.toFloat() / tasks.size },
                    modifier = Modifier.fillMaxWidth().height(7.dp),
                    color = Orange,
                    trackColor = Color.DarkGray
                )
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("افزودن کار جدید", color = Gold, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f).background(Panel, RoundedCornerShape(12.dp)).padding(14.dp)) {
                if (newTask.isEmpty()) Text("مثلاً: ۳۰ دقیقه آموزش ترید", color = Muted)
                BasicTextField(value = newTask, onValueChange = { newTask = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp))
            }
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (newTask.isNotBlank()) {
                    update(tasks + TaskItem(System.currentTimeMillis(), newTask.trim(), false))
                    newTask = ""
                }
            }, colors = ButtonDefaults.buttonColors(containerColor = Orange), shape = RoundedCornerShape(12.dp)) {
                Icon(Icons.Default.Add, null)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("چک‌لیست", color = Gold, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        if (tasks.isEmpty()) {
            Text("هنوز کاری ثبت نکردی. اولین قدم رو اضافه کن!", color = Muted, modifier = Modifier.padding(top = 18.dp))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tasks, key = { it.id }) { task ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = task.done, onCheckedChange = { checked ->
                                update(tasks.map { if (it.id == task.id) it.copy(done = checked) else it })
                            }, colors = CheckboxDefaults.colors(checkedColor = Orange))
                            Text(task.title, color = if (task.done) Muted else Color.White,
                                modifier = Modifier.weight(1f), textDecoration = if (task.done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null)
                            IconButton(onClick = { update(tasks.filterNot { it.id == task.id }) }) {
                                Icon(Icons.Default.Delete, "حذف", tint = Muted)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GoalsScreen(modifier: Modifier = Modifier) {
    val goals = listOf(
        "ترید و مدیریت ریسک" to "تمرکز روی کیفیت ستاپ، ژورنال و کنترل ریسک",
        "سلامتی و افزایش وزن" to "تغذیه منظم، تمرین و پیگیری وزن",
        "یادگیری روانشناسی" to "مطالعه عمیق و یادداشت‌برداری",
        "یادگیری هوش مصنوعی" to "یادگیری از پایه با هدف ساخت مهارت درآمدزا"
    )
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Header("اهداف اصلی", "پیشرفت واقعی از استمرار می‌آید")
        goals.forEach { (title, desc) ->
            Card(Modifier.fillMaxWidth().padding(bottom = 12.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(desc, color = Muted, fontSize = 13.sp)
                }
            }
        }
        Text("در نسخه بعدی، برای هر هدف شاخص پیشرفت و گزارش هفتگی اضافه می‌شود.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun AssistantScreen(modifier: Modifier = Modifier) {
    var input by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("سلام! من دستیار برنامه‌ریزی تو هستم. گزارش امروزت رو بنویس تا با هم بررسی کنیم.") }
    var busy by remember { mutableStateOf(false) }
    var serverUrl by remember { mutableStateOf("https://YOUR-SERVER.example.com/chat") }
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Header("دستیار هوشمند", "گفتگو، بررسی عملکرد و برنامه‌ریزی")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f).fillMaxWidth()) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Text(reply, color = Color.White, fontSize = 15.sp)
                if (busy) {
                    Spacer(Modifier.height(12.dp))
                    CircularProgressIndicator(color = Orange, modifier = Modifier.size(24.dp))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = serverUrl, onValueChange = { serverUrl = it },
            label = { Text("آدرس سرور امن API") }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, unfocusedBorderColor = Muted))
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = input, onValueChange = { input = it },
            label = { Text("پیامت رو بنویس...") }, modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Orange, unfocusedBorderColor = Muted))
        Spacer(Modifier.height(8.dp))
        Button(enabled = input.isNotBlank() && !busy, onClick = {
            val message = input
            input = ""
            busy = true
            reply = "در حال دریافت پاسخ..."
            Thread {
                val result = callAssistant(serverUrl, message)
                android.os.Handler(contextMainLooper()).post {
                    reply = result
                    busy = false
                }
            }.start()
        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
            Text("ارسال به دستیار")
        }
    }
}

private fun contextMainLooper() = android.os.Looper.getMainLooper()

private fun callAssistant(endpoint: String, message: String): String {
    return try {
        if (!endpoint.startsWith("https://") || endpoint.contains("YOUR-SERVER")) {
            return "برای فعال شدن GPT، ابتدا سرور امن را راه‌اندازی کن و آدرس آن را اینجا وارد کن. کلید API را داخل اپ وارد نکن."
        }
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        conn.outputStream.use { it.write(JSONObject().put("message", message).toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        JSONObject(body).optString("reply", "پاسخ معتبری از سرور دریافت نشد.")
    } catch (e: Exception) {
        "اتصال برقرار نشد. آدرس سرور و اینترنت را بررسی کن. (${e.localizedMessage ?: "خطای نامشخص"})"
    }
}

private fun loadTasks(context: Context): List<TaskItem> {
    return try {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(TASKS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            TaskItem(o.getLong("id"), o.getString("title"), o.getBoolean("done"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveTasks(context: Context, tasks: List<TaskItem>) {
    val arr = JSONArray()
    tasks.forEach { arr.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done)) }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(TASKS, arr.toString()).apply()
}
