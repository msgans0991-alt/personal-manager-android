import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "32kb" }));

const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) console.warn("OPENAI_API_KEY is not configured.");

const client = apiKey ? new OpenAI({ apiKey }) : null;

app.get("/health", (_req, res) => res.json({ ok: true }));

app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body?.message ?? "").trim();
    if (!message || message.length > 8000) {
      return res.status(400).json({ error: "پیام خالی یا بیش از حد طولانی است." });
    }
    if (!client) return res.status(503).json({ error: "سرور هنوز به OpenAI API متصل نشده است." });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: "تو دستیار شخصی فارسی‌زبان، دقیق، منظم و محترم هستی. به کاربر برای برنامه‌ریزی، پیگیری وظایف، ارزیابی گزارش روزانه و مدیریت زمان کمک کن. در ترید هرگز سود تضمینی نده و بر مدیریت ریسک تأکید کن. پاسخ‌ها عملی، روشن و بدون سرزنش باشند.",
      input: message
    });
    res.json({ reply: response.output_text || "پاسخی دریافت نشد." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "خطا در دریافت پاسخ از سرویس هوش مصنوعی." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Personal Manager API listening on ${port}`));
